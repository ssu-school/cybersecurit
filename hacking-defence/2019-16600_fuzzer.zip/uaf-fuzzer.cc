#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "uaf.h"

void hex_dump(const uint8_t *data, uint32_t size) {
    int32_t remaining = (int32_t) size, offset, i;
    for (offset = 0; remaining> 0; offset+=8,remaining-=8){
	    printf("%016x ",data+offset);
	    if (remaining <8){
		    for(i = 0; i<remaining; i++)
			    printf("%02x ", *(data + offset + i));
	    } else{
		    for(i=0; i<8; i++)
			    printf("%02x ", *(data + offset + i));
	    }
	    printf("\n");
    }
}
extern "C" int LLVMFuzzerTestOneInput(const uint8_t* Data, size_t Size) {
    // TODO: Write down your fuzz driver
    uint8_t *data;
    data = (uint8_t *) malloc(sizeof(uint8_t) * Size);
    *data = *Data; 
    uint8_t* buf = nullptr;
    uint8_t* pMax = nullptr;
    uint8_t vMax;
    if (copyToBuffer(static_cast<const uint8_t*>(data), Size,buf, pMax, vMax) != false)
      overrideMax(pMax, vMax, vMax + 1);
    hex_dump(reinterpret_cast<const uint8_t*>(buf), Size);
    if(buf)
	    free(buf);
    if(data)
	    free(data);
    return 0;
}
